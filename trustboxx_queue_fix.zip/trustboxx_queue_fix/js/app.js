/* P1 Frontend — single JavaScript file */

/* ==========================================================================
   ENVIRONMENT CONFIG — edit only this block to change the backend URL / endpoints.
   Never put secrets or API keys here (static site, visible to users).
   ========================================================================== */
window.ENV = Object.freeze({
  API_BASE_URL: "http://192.168.1.104:8000", // host only, no trailing slash, no /api (paths below include /api)
  // Same as the backend Swagger (No Overnight Enquiry Wait 0.1.0). {enquiry_id} is filled in automatically.
  ENDPOINTS: Object.freeze({
    ENQUIRY_CREATE:   "/api/enquiry",                          // POST
    ENQUIRY_GET:      "/api/enquiry/{enquiry_id}",             // GET
    ENQUIRY_MESSAGES: "/api/enquiry/{enquiry_id}/messages",    // GET
    ENQUIRIES_LIST:   "/api/enquiries",                        // GET
    MOCK_WHATSAPP:    "/api/mock/whatsapp",                    // POST
    DIGEST_PREVIEW:   "/api/digest/preview",                   // GET
    DIGEST_SEND:      "/api/digest/send",                      // POST
    HEALTH:           "/api/health"                            // GET
  }),
  API_TIMEOUT_MS: 15000
});

/* ===== API ===== */
/* Frontend API adapter. Reads all URLs from window.ENV above. */
(() => {
  const ENV = window.ENV;
  const baseUrl = String(ENV.API_BASE_URL || "").replace(/\/+$/, "");
  const EP = ENV.ENDPOINTS;
  const withId = (tpl, id) => tpl.replace("{enquiry_id}", encodeURIComponent(id));
  const API = {
    baseUrl,
    async request(path, options = {}) {
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), ENV.API_TIMEOUT_MS || 15000);
      let response;
      try {
        response = await fetch(`${this.baseUrl}${path}`, {
          ...options,
          signal: controller.signal,
          headers: { "Content-Type": "application/json", ...(options.headers || {}) }
        });
      } catch (err) {
        throw new Error(err.name === "AbortError" ? "Request timed out" : err.message);
      } finally { clearTimeout(timer); }
      let payload;
      try { payload = await response.json(); } catch { payload = {}; }
      if (!response.ok) throw new Error(payload.message || payload.detail || `Request failed (${response.status})`);
      return payload;
    },
    submitEnquiry: payload => API.request(EP.ENQUIRY_CREATE, { method: "POST", body: JSON.stringify(payload) }),
    getEnquiry: id => API.request(withId(EP.ENQUIRY_GET, id)),
    getEnquiryMessages: id => API.request(withId(EP.ENQUIRY_MESSAGES, id)),
    getEnquiries: () => API.request(EP.ENQUIRIES_LIST),
    submitWhatsApp: payload => API.request(EP.MOCK_WHATSAPP, { method: "POST", body: JSON.stringify(payload) }),
    previewDigest: () => API.request(EP.DIGEST_PREVIEW),
    sendDigest: () => API.request(EP.DIGEST_SEND, { method: "POST", body: JSON.stringify({}) }),
    health: () => API.request(EP.HEALTH)
  };
  window.P1API = API;
})();

/* ===== ENQUIRIES ===== */
(() => {
  const state = { records: [], apiAvailable: false, lastUpdated: new Date() };
  function titleSource(source) { return ({email:"Email",whatsapp:"WhatsApp",web_form:"Web Form",salesiq:"SalesIQ"})[source] || source; }
  function initials(name) { return (name || "NA").trim().split(/\s+/).slice(0,2).map(s=>s[0]).join("").toUpperCase(); }
  function timeLabel(value) { const d = new Date(value); return Number.isNaN(d.getTime()) ? "—" : d.toLocaleTimeString("en-IN",{hour:"2-digit",minute:"2-digit",hour12:false}); }
  function dateTimeLabel(value) { const d = new Date(value); return Number.isNaN(d.getTime()) ? "—" : d.toLocaleString("en-IN",{day:"2-digit",month:"short",hour:"2-digit",minute:"2-digit",hour12:false}); }
  function escapeHtml(value) { return String(value ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c])); }
  function normalizedRecord(raw) {
    const source = raw.source || "web_form";
    return { ...raw, enquiry_id:raw.enquiry_id || "", source, patient_name:raw.patient_name || "Unknown patient", patient_country:raw.patient_country || "Not provided", condition:raw.condition || raw.raw_message || "General enquiry", urgency:raw.urgency || "standard", status:raw.status || "pending", received_at:raw.received_at || new Date().toISOString(), clinical_flag:Boolean(raw.clinical_flag), zoho_lead_id:raw.zoho_lead_id || null };
  }
  async function add(payload) {
    const response = payload.source === "whatsapp" && payload.from
      ? await window.P1API.submitWhatsApp({from:payload.from,message:payload.raw_message})
      : await window.P1API.submitEnquiry({source:payload.source,raw_message:payload.raw_message,patient_name:payload.patient_name,patient_email:payload.patient_email || "",patient_phone:payload.patient_phone || ""});
    return normalizedRecord({ ...payload, ...response, received_at:new Date().toISOString() });
  }
  async function refresh() {
    const response = await window.P1API.getEnquiries();
    state.records = (response.enquiries || []).map(normalizedRecord);
    state.apiAvailable = true; state.lastUpdated = new Date(); return state.records;
  }
  function getFiltered() {
    const search = (document.getElementById("searchInput")?.value || "").trim().toLowerCase();
    const source = document.getElementById("sourceFilter")?.value || "";
    const urgency = document.getElementById("urgencyFilter")?.value || "";
    const status = document.getElementById("statusFilter")?.value || "";
    const dateFrom = document.getElementById("dateFrom")?.value || "";
    const dateTo = document.getElementById("dateTo")?.value || "";
    return state.records.filter(r => {
      const recordDate = new Date(r.received_at);
      const day = Number.isNaN(recordDate.getTime()) ? "" : [
        recordDate.getFullYear(),
        String(recordDate.getMonth() + 1).padStart(2, "0"),
        String(recordDate.getDate()).padStart(2, "0")
      ].join("-");
      return (!search || `${r.patient_name} ${r.condition} ${r.patient_country}`.toLowerCase().includes(search)) &&
        (!source || r.source === source) &&
        (!urgency || r.urgency === urgency) &&
        (!status || r.status === status) &&
        (!dateFrom || (day && day >= dateFrom)) &&
        (!dateTo || (day && day <= dateTo));
    });
  }
  function render() {
    const body = document.getElementById("enquiryTableBody"); if (!body) return;
    const records = getFiltered();
    body.innerHTML = records.length ? records.map((r,i) => {
      const avatarClass = ["","pink","green","amber","purple"][i%5];
      const urgency = ["urgent","standard","info"].includes(r.urgency) ? r.urgency : "standard";
      const status = ["pending","processed","held_for_human"].includes(r.status) ? r.status : "pending";
      const statusText = {pending:"Pending",processed:"Processed",held_for_human:"⚠ Held for human"}[status];
      const sourceText = titleSource(r.source);
      const crm = r.zoho_lead_id ? `<a class="crm-link" href="#" data-crm="${escapeHtml(r.zoho_lead_id)}">View lead ↗</a>` : `<span class="crm-link disabled" title="CRM is not connected">Not connected</span>`;
      return `<tr><td><div class="patient-cell"><div class="patient-avatar ${avatarClass}">${escapeHtml(initials(r.patient_name))}</div><div><div class="patient-name">${escapeHtml(r.patient_name)}</div><div class="patient-procedure">${escapeHtml(r.condition)}</div></div></div></td><td><span class="source-chip ${escapeHtml(r.source)}">${escapeHtml(sourceText.toUpperCase())}</span></td><td><span class="urgency-badge ${urgency}">${urgency==="urgent"?"● ":""}${urgency==="info"?"INFO-ONLY":urgency.toUpperCase()}</span></td><td><span class="status-badge ${status}">${statusText}</span></td><td>${escapeHtml(timeLabel(r.received_at))}</td><td>${crm}</td></tr>`;
    }).join("") : `<tr><td colspan="6" class="empty-state">No enquiries match these filters. Try changing your search.</td></tr>`;
    document.getElementById("totalMetric").textContent = state.records.length;
    document.getElementById("urgentMetric").textContent = state.records.filter(r=>r.status==="held_for_human" || r.urgency==="urgent").length;
    document.getElementById("processedMetric").textContent = state.records.filter(r=>r.status==="processed").length;
    document.getElementById("pendingMetric").textContent = state.records.filter(r=>r.status==="pending").length;
    document.getElementById("navCount").textContent = state.records.length;
    document.getElementById("queueCount").textContent = records.length;
    document.getElementById("tableSummary").textContent = `Showing ${records.length} of ${state.records.length} enquiries`;
    document.getElementById("lastUpdated").textContent = `Updated ${state.lastUpdated.toLocaleTimeString("en-IN",{hour:"2-digit",minute:"2-digit"})}`;
    renderActivity();
  }
  function renderActivity() {
    const target = document.getElementById("activityList");
    const recent = [...state.records].sort((a,b)=>new Date(b.received_at)-new Date(a.received_at)).slice(0,3);
    target.innerHTML = recent.map(r => {
      const type = r.status==="held_for_human" ? "urgent" : r.status==="pending" ? "pending" : r.urgency==="info" ? "info" : "processed";
      const symbol = type==="urgent" ? "!" : type==="pending" ? "◷" : type==="info" ? "i" : "✓";
      const label = type==="urgent" ? "Human review required" : type==="pending" ? "Enquiry awaiting processing" : type==="info" ? "Information request received" : "Enquiry processed";
      return `<div class="activity-item"><div class="activity-symbol ${type}">${symbol}</div><div class="activity-copy"><strong>${escapeHtml(label)}</strong><p>${escapeHtml(r.patient_name)} · ${escapeHtml(r.condition)}</p></div><span class="activity-time">${escapeHtml(timeLabel(r.received_at))}</span></div>`;
    }).join("");
  }
  window.P1Enquiries = { state, add, refresh, render, getFiltered, escapeHtml, titleSource, timeLabel, dateTimeLabel, normalizedRecord };
})();

/* ===== SIMULATIONS: EMAIL + BACKEND-DRIVEN CHATBOT ===== */
(() => {
  const $ = id => document.getElementById(id);
  function feedback(message, type="success", targetId="formFeedback") {
    const el = $(targetId);
    if (!el) return;
    el.hidden = false;
    el.className = `inline-feedback ${type}`;
    el.textContent = message;
  }
  const wait = ms => new Promise(resolve => setTimeout(resolve, ms));

  /* ---- Reply handling: GET /api/enquiry/{enquiry_id}/messages ----
     POST /api/enquiry only returns an acknowledgement ("Enquiry received. AI agent
     processing started."). The real AI reply is written later by the backend and is
     read from the messages endpoint, so we poll that endpoint. */
  const ACK_PATTERN = /enquiry received|processing started/i;
  const TEXT_KEYS = ["content", "body", "text", "message", "message_text", "reply", "ai_reply", "response"];
  const SENDER_KEYS = ["direction", "role", "sender", "sender_type", "author", "from", "type"];

  function messageText(m) {
    if (typeof m === "string") return m.trim();
    if (!m || typeof m !== "object") return "";
    for (const key of TEXT_KEYS) {
      if (typeof m[key] === "string" && m[key].trim()) return m[key].trim();
    }
    return "";
  }

  // false for messages written by the patient (inbound / user), true for AI / agent / outbound
  function isFromAssistant(m) {
    if (!m || typeof m !== "object") return true;
    for (const key of SENDER_KEYS) {
      if (typeof m[key] !== "string") continue;
      const tag = m[key].toLowerCase();
      if (/\b(inbound|incoming|user|patient|customer|visitor|lead)\b/.test(tag)) return false;
      if (/\b(outbound|outgoing|assistant|ai|agent|bot|system|reply)\b/.test(tag)) return true;
    }
    return true; // no sender info: the echo filter in pickAiReply handles it
  }

  function toMessageList(payload) {
    if (Array.isArray(payload)) return payload;
    if (payload && typeof payload === "object") {
      for (const key of ["messages", "data", "items", "results"]) {
        if (Array.isArray(payload[key])) return payload[key];
      }
    }
    return [];
  }

  // Newest AI message that is not the patient's own text and not the "received" acknowledgement
  function pickAiReply(payload, sentMessage) {
    const sent = String(sentMessage || "").trim();
    const replies = toMessageList(payload)
      .filter(isFromAssistant)
      .map(messageText)
      .filter(text => text && !ACK_PATTERN.test(text) && text !== sent && !sent.endsWith(text));
    return replies.length ? replies[replies.length - 1] : "";
  }

  async function getBackendReply(enquiryId, sentMessage, options = {}) {
    const { intervalMs = 2000, maxAttempts = 45 } = options;
    if (!enquiryId) throw new Error("The backend did not return an enquiry_id, so the reply cannot be fetched.");

    for (let attempt = 0; attempt < maxAttempts; attempt++) {
      await wait(attempt === 0 ? 1000 : intervalMs);

      // 1) the AI reply, from /api/enquiry/{enquiry_id}/messages
      try {
        const payload = await window.P1API.getEnquiryMessages(enquiryId);
        if (attempt === 0) console.debug("[P1] /messages payload:", payload);
        const reply = pickAiReply(payload, sentMessage);
        if (reply) return reply;
      } catch (error) {
        console.debug("[P1] messages not ready yet:", error.message); // usually 404 until the agent writes
      }

      // 2) stop early if the backend gave up or handed the enquiry to a human
      let status = "";
      try {
        const enquiry = await window.P1API.getEnquiry(enquiryId);
        status = String(enquiry.status || "").toLowerCase();
      } catch (error) { /* keep polling */ }
      if (["held_for_human", "failed", "error"].includes(status)) {
        throw new Error(status === "held_for_human"
          ? "This enquiry was held for human review, so no automatic reply was sent."
          : "The backend could not generate a reply for this enquiry.");
      }
    }
    throw new Error("The enquiry was submitted, but no AI reply appeared yet. Check the backend and try again.");
  }

  function addChatMessage(text, role, note="") {
    const target = $("chatMessages");
    if (!target) return;
    const item = document.createElement("div");
    item.className = `chat-message ${role}`;
    const avatar = document.createElement("div");
    avatar.className = "chat-message-avatar";
    avatar.textContent = role === "user" ? "Y" : "TB";
    const bubble = document.createElement("div");
    bubble.className = "chat-bubble";
    const title = document.createElement("strong");
    title.textContent = role === "user" ? "You" : "TrustBoxx Assistant";
    const paragraph = document.createElement("p");
    paragraph.textContent = text;
    bubble.append(title, paragraph);
    if (note) {
      const small = document.createElement("small");
      small.textContent = note;
      bubble.append(small);
    }
    item.append(avatar, bubble);
    target.append(item);
    target.scrollTop = target.scrollHeight;
    return item;
  }

  const enquiryForm = $("enquiryForm");
  if (enquiryForm) {
    enquiryForm.addEventListener("submit", async event => {
      event.preventDefault();
      if (!enquiryForm.reportValidity()) return;
      const button = enquiryForm.querySelector('button[type="submit"]');
      const old = button.innerHTML;
      button.disabled = true; button.textContent = "Submitting…";
      try {
        const f = new FormData(enquiryForm);
        const record = await window.P1Enquiries.add({
          source:f.get("source"), patient_name:f.get("patient_name"),
          patient_country:f.get("patient_country"), patient_email:f.get("patient_email"),
          raw_message:f.get("raw_message")
        });
        feedback("Enquiry received — waiting for backend processing…", "success");
        window.P1Enquiries.render();
        if (record.enquiry_id) {
          try {
            await getBackendReply(record.enquiry_id, f.get("raw_message"));
            feedback("Backend processing completed.", "success");
          } catch (error) {
            feedback(error.message, "warning");
          }
        }
        enquiryForm.reset();
        window.P1Toast.show("Test enquiry submitted.", "success");
      } catch (error) {
        feedback(`Could not submit enquiry: ${error.message}`, "error");
        window.P1Toast.show(`Submission failed: ${error.message}`, "error");
      } finally { button.disabled = false; button.innerHTML = old; }
    });
  }

  const emailForm = $("emailForm");
  if (emailForm) {
    emailForm.addEventListener("submit", async event => {
      event.preventDefault();
      if (!emailForm.reportValidity()) return;
      const button = emailForm.querySelector('button[type="submit"]');
      const old = button.innerHTML;
      button.disabled = true; button.textContent = "Sending…";
      const formData = new FormData(emailForm);
      const name = String(formData.get("name") || "").trim();
      const email = String(formData.get("email") || "").trim();
      const message = String(formData.get("message") || "").trim();
      $("emailReplyContent").innerHTML = '<div class="reply-placeholder-icon">◷</div><h3>Generating reply</h3><p>Your email has been submitted. The reply will appear here shortly…</p>';
      $("replyTo").textContent = email;
      $("emailReplyStatus").textContent = "Processing…";
      try {
        const record = await window.P1Enquiries.add({
          source:"email", patient_name:name, patient_email:email,
          raw_message:`Subject: ${String(formData.get("subject") || "International treatment enquiry").trim()}\n\n${message}`
        });
        feedback(`Email enquiry submitted${record.enquiry_id ? ` · Reference: ${record.enquiry_id}` : ""}. Waiting for the AI reply…`, "success", "emailFeedback");
        window.P1Enquiries.render();
        const reply = await getBackendReply(record.enquiry_id, message);
        $("emailReplyContent").replaceChildren();
        const p = document.createElement("p"); p.className = "email-reply-text"; p.textContent = reply;
        $("emailReplyContent").append(p);
        $("emailReplyStatus").textContent = "Reply received";
        feedback("AI reply received.", "success", "emailFeedback");
        window.P1Toast.show("Email simulation completed.", "success");
      } catch (error) {
        $("emailReplyStatus").textContent = "Reply unavailable";
        $("emailReplyContent").replaceChildren();
        const p = document.createElement("p"); p.className = "email-reply-text error-text";
        p.textContent = error.message;
        $("emailReplyContent").append(p);
        feedback(error.message, "error", "emailFeedback");
        window.P1Toast.show(`Email simulation: ${error.message}`, "error");
      } finally { button.disabled = false; button.innerHTML = old; }
    });
  }

  const chatForm = $("chatForm");
  if (chatForm) {
    const messageInput = $("chatMessage");
    messageInput.addEventListener("keydown", event => {
      if (event.key === "Enter" && !event.shiftKey) {
        event.preventDefault();
        chatForm.requestSubmit();
      }
    });
    chatForm.addEventListener("submit", async event => {
      event.preventDefault();
      if (!chatForm.reportValidity()) return;
      const button = chatForm.querySelector('button[type="submit"]');
      const message = String(messageInput.value || "").trim();
      if (!message) return;
      addChatMessage(message, "user", new Date().toLocaleTimeString([], {hour:"2-digit", minute:"2-digit"}));
      messageInput.value = "";
      button.disabled = true; button.textContent = "Sending…";
      $("chatFeedback").hidden = true;
      const thinking = addChatMessage("Sending your message to the backend and waiting for the AI response…", "assistant", "Connecting to backend");
      thinking.classList.add("thinking-message");
      try {
        const record = await window.P1Enquiries.add({
          source:"salesiq", raw_message:message
        });
        const reply = await getBackendReply(record.enquiry_id, message);
        thinking.remove();
        addChatMessage(reply, "assistant", "Backend response · " + new Date().toLocaleTimeString([], {hour:"2-digit", minute:"2-digit"}));
        window.P1Enquiries.refresh().then(()=>window.P1Enquiries.render()).catch(()=>{});
      } catch (error) {
        thinking.remove();
        addChatMessage("I couldn't retrieve a response from the backend. Please try again after checking the backend service.", "assistant", "Response unavailable");
        $("chatFeedback").hidden = false;
        $("chatFeedback").textContent = error.message;
        $("chatFeedback").className = "chat-error";
      } finally {
        button.disabled = false; button.innerHTML = '<span aria-hidden="true">➤</span>'; messageInput.focus();
      }
    });
  }
  const clearChat = $("clearChat");
  if (clearChat) clearChat.addEventListener("click", () => {
    $("chatMessages").innerHTML = "";
    addChatMessage("Hello! How can I help with your international treatment enquiry today?", "assistant", "Welcome message");
    $("chatFeedback").hidden = true;
  });

  const jump = $("jumpToForm");
  if (jump && enquiryForm) jump.addEventListener("click", () => {
    $("newEnquiry").scrollIntoView({behavior:"smooth",block:"center"});
    enquiryForm.querySelector("input").focus({preventScroll:true});
  });
  window.P1Simulations = { feedback };
})();

/* ===== DIGEST (separate "Digest preview" page, table layout) ===== */
(() => {
  const $ = id => document.getElementById(id);
  const e = window.P1Enquiries;
  const esc = v => e.escapeHtml(v);
  const clean = s => String(s || "").replace(/\s+/g, " ").trim();
  const GROUPS = [
    { key: "urgent",   label: "Urgent",    note: "Requires attention today" },
    { key: "standard", label: "Standard",  note: "" },
    { key: "info",     label: "Info only", note: "" }
  ];

  /* --- 1) read the leads out of the backend's email HTML (html_body) --- */
  function htmlToLines(html) {
    const doc = new DOMParser().parseFromString(String(html || ""), "text/html");
    doc.querySelectorAll("style,script,title").forEach(n => n.remove());
    doc.querySelectorAll("br").forEach(n => n.replaceWith("\n"));
    doc.querySelectorAll("td,th").forEach(n => n.append(" "));
    doc.querySelectorAll("p,div,tr,li,h1,h2,h3,h4,h5,h6,table,section").forEach(n => { n.prepend("\n"); n.append("\n"); });
    return (doc.body ? doc.body.textContent : "").split("\n").map(clean).filter(Boolean);
  }
  function applyReceived(row, text) {
    const t = text.match(/Received:\s*([^|]+?)\s*(?:\||$)/i);
    const c = text.match(/Channel:\s*([^|]+?)\s*(?:\||$)/i);
    if (t) row.time = clean(t[1]);
    if (c) row.channel = clean(c[1]);
    const extra = text.split("|").map(clean).filter(p => p && !/^(Received|Channel):/i.test(p));
    if (extra.length) row.note = extra.join(" · ");
  }
  function parseDigestHtml(html) {
    const lines = htmlToLines(html);
    const counts = {}, rows = [];
    let group = "standard", last = null;
    for (const line of lines) {
      const head = line.match(/^[^A-Za-z]*(URGENT|STANDARD|INFO[\s-]*ONLY)\b[^:]*:\s*(\d+)\s*$/i);
      if (head) {
        group = /urgent/i.test(head[1]) ? "urgent" : /standard/i.test(head[1]) ? "standard" : "info";
        counts[group] = Number(head[2]); last = null; continue;
      }
      const item = line.match(/^(\d+)\.\s+(.+)$/);
      if (item && item[2].includes("|")) {
        const [main, after] = item[2].split(/\bReceived:/i);
        const [name, country, ...rest] = main.split("|").map(clean);
        last = { group, name: name || "Unknown", country: clean((country || "").replace(/^Country\s*/i, "")) || "—",
                 enquiry: rest.join(" | ") || "—", channel: "", time: "", note: "", crm: "" };
        if (/^n\/a$/i.test(last.country)) last.country = "—";
        if (after) applyReceived(last, "Received:" + after);
        rows.push(last); continue;
      }
      if (!last) continue;
      if (/^Received:/i.test(line)) { applyReceived(last, line); continue; }
      const crm = line.match(/^CRM\b[\s:(-]*(.*?)[\s)]*$/i);
      if (crm) last.crm = clean(crm[1]);
    }
    return rows.length ? { rows, counts } : null;
  }

  /* --- 2) fallback: build rows from the queue records --- */
  function rowsFromRecords(records, since) {
    const cutoff = since ? new Date(since) : null;
    return records
      .filter(r => !cutoff || isNaN(cutoff) || new Date(r.received_at) >= cutoff)
      .sort((a, b) => new Date(b.received_at) - new Date(a.received_at))
      .map(r => ({
        group: (r.urgency === "urgent" || r.status === "held_for_human") ? "urgent" : r.urgency === "info" ? "info" : "standard",
        name: r.patient_name || "Unknown", country: /^not provided$/i.test(r.patient_country || "") ? "—" : (r.patient_country || "—"),
        enquiry: r.condition || "—", channel: e.titleSource(r.source), time: e.timeLabel(r.received_at) + " IST",
        note: r.status === "held_for_human" ? "Human approval needed" : "", crm: ""
      }));
  }

  /* --- 3) draw chips (clickable filters) + table --- */
  function tagClass(channel) {
    const c = String(channel).toLowerCase();
    return c.includes("sales") ? "t-salesiq" : c.includes("mail") ? "t-email" : c.includes("whats") ? "t-wa" : "t-web";
  }
  function crmLabel(text) {
    const t = clean(text).replace(/^\(|\)$/g, "");
    return t ? t.charAt(0).toUpperCase() + t.slice(1) : "Not connected";
  }

  let view = { rows: [], counts: {}, total: 0, queue: false, since: "" };
  let activeGroup = "all";
  let lastApi = null;

  function renderPreview(apiData, opts = {}) {
    lastApi = apiData;
    const queueView = Boolean(opts.queueView);
    const parsed = !queueView && apiData && apiData.html_body ? parseDigestHtml(apiData.html_body) : null;
    const rows = queueView ? rowsFromRecords(e.state.records, null)
               : parsed ? parsed.rows
               : rowsFromRecords(e.state.records, apiData && apiData.covers_since);
    const counts = {};
    GROUPS.forEach(g => { counts[g.key] = (parsed && parsed.counts[g.key] != null) ? parsed.counts[g.key] : rows.filter(r => r.group === g.key).length; });
    const sum = GROUPS.reduce((n, g) => n + counts[g.key], 0);
    const total = queueView ? rows.length : (apiData && apiData.total != null) ? apiData.total : sum;

    let since = apiData && apiData.covers_since ? String(apiData.covers_since) : "";
    const sinceDate = since ? new Date(since) : null;
    if (sinceDate && !isNaN(sinceDate)) since = sinceDate.toLocaleString("en-IN", { day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit", hour12: false }) + " IST";
    view = { rows, counts, total, queue: queueView, since };

    $("digestTitle").textContent = "Overnight Enquiry Digest — " + new Date().toLocaleDateString("en-IN", { day: "2-digit", month: "short", year: "numeric" });
    $("digestSubtitle").textContent = queueView ? "Showing every enquiry currently in the queue — this is not what the email will contain"
      : since ? "Covers enquiries since " + since : "Preview generated from the current queue";
    $("digestTotal").textContent = total + " lead" + (total === 1 ? "" : "s");
    renderView();
  }

  function renderView() {
    const { rows, counts, total, queue, since } = view;
    const chip = (key, label, n) => `<button type="button" class="dp-chip ${key}${activeGroup === key ? " active" : ""}" data-filter="${key}" aria-pressed="${activeGroup === key}"><b>${n}</b> ${label}</button>`;
    $("digestChips").className = "dp-chips" + (activeGroup !== "all" ? " has-filter" : "");
    $("digestChips").innerHTML = chip("all", "All", total) + GROUPS.map(g => chip(g.key, g.label, counts[g.key])).join("");

    if (!rows.length) {
      $("digestBody").innerHTML = queue
        ? '<div class="dp-empty">The queue is empty — no enquiries have been received yet.</div>'
        : `<div class="dp-empty"><strong>No enquiries in this digest window.</strong><br>The digest covers enquiries received ${since ? "since " + esc(since) : "overnight"}. Nothing has arrived since then, so the email would be empty.<br><button type="button" class="button button-secondary dp-link-btn" id="showQueueView">Show all enquiries in the queue</button></div>`;
      return;
    }
    const shown = activeGroup === "all" ? rows : rows.filter(r => r.group === activeGroup);
    if (!shown.length) {
      const g = GROUPS.find(x => x.key === activeGroup);
      $("digestBody").innerHTML = `<div class="dp-empty">No ${esc(g.label.toLowerCase())} enquiries in this digest.</div>`;
      return;
    }
    let n = 0;
    const body = GROUPS.map(g => {
      const list = shown.filter(r => r.group === g.key);
      if (!list.length) return "";
      return `<tr class="dp-group ${g.key}"><td colspan="8">${g.label.toUpperCase()}${g.note ? `<small>${g.note}</small>` : ""} · ${list.length}</td></tr>` +
        list.map(r => `<tr><td class="dp-num">${++n}</td><td class="dp-name">${esc(r.name)}</td><td>${esc(r.country)}</td><td>${esc(r.enquiry)}</td>` +
          `<td>${r.channel ? `<span class="dp-tag ${tagClass(r.channel)}">${esc(String(r.channel).toUpperCase())}</span>` : "—"}</td>` +
          `<td class="dp-time">${esc(r.time || "—")}</td><td>${r.note ? `<span class="dp-flag">⚠ ${esc(r.note)}</span>` : '<span class="dp-dash">—</span>'}</td>` +
          `<td class="dp-crm">${esc(crmLabel(r.crm))}</td></tr>`).join("");
    }).join("");
    let note = "";
    if (queue) note = '<p class="dp-more">Queue view. <button type="button" class="dp-inline-link" id="showDigestWindow">Back to the digest window</button></p>';
    else if (activeGroup === "all" && rows.length < total) note = `<p class="dp-more">Showing ${rows.length} of ${total} leads included in the email.</p>`;
    $("digestBody").innerHTML = `<div class="dp-table-wrap"><table class="dp-table"><thead><tr><th>#</th><th>PATIENT</th><th>COUNTRY</th><th>ENQUIRY</th><th>CHANNEL</th><th>RECEIVED</th><th>NOTE</th><th>CRM</th></tr></thead><tbody>${body}</tbody></table></div>${note}`;
  }

  let loading = false;
  async function loadPreview() {
    if (loading) return; loading = true;
    activeGroup = "all";
    const btn = $("refreshDigest"); if (btn) btn.disabled = true;
    $("digestChips").innerHTML = ""; $("digestTotal").textContent = "…";
    $("digestBody").innerHTML = '<div class="dp-empty">Preparing digest preview…</div>';
    try {
      renderPreview(await window.P1API.previewDigest());
    } catch (error) {
      $("digestTotal").textContent = "0 leads";
      $("digestBody").innerHTML = `<div class="dp-empty dp-error">Could not load the digest preview: ${esc(error.message)}. Check that the backend is running.</div>`;
      window.P1Toast.show(`Could not load digest: ${error.message}`, "error");
    } finally { loading = false; if (btn) btn.disabled = false; }
  }

  $("digestChips").addEventListener("click", ev => {
    const b = ev.target.closest("[data-filter]"); if (!b) return;
    activeGroup = (b.dataset.filter === activeGroup) ? "all" : b.dataset.filter;
    renderView();
  });
  $("digestBody").addEventListener("click", ev => {
    if (ev.target.closest("#showQueueView")) renderPreview(lastApi, { queueView: true });
    else if (ev.target.closest("#showDigestWindow")) renderPreview(lastApi);
  });
  $("previewDigest").addEventListener("click", () => { window.P1Nav.showPage("page-digest"); loadPreview(); });
  $("refreshDigest").addEventListener("click", loadPreview);
  const digestLink = document.querySelector('.nav-link[data-page="page-digest"]');
  if (digestLink) digestLink.addEventListener("click", loadPreview);
  $("sendDigest").addEventListener("click", async () => {
    const button = $("sendDigest"); button.disabled = true; button.textContent = "Sending…";
    try {
      const result = await window.P1API.sendDigest();
      window.P1Toast.show(`Backend confirmed digest request. Leads included: ${result.leads_included ?? "reported by API"}.`, "success");
    } catch (error) { window.P1Toast.show(`Digest send failed: ${error.message}`, "error"); }
    finally { button.disabled = false; button.innerHTML = 'Send digest now <span>→</span>'; }
  });
  window.P1Digest = { renderPreview, loadPreview };
  if (location.hash === "#page-digest") loadPreview();
})();

/* ===== APP ===== */
(() => {
  const $ = id => document.getElementById(id);
  window.P1Toast = {
    show(message, type="success") {
      const region=$("toastRegion"), el=document.createElement("div");
      el.className=`toast ${type}`; el.textContent=message; region.appendChild(el);
      setTimeout(()=>el.remove(),4200);
    }
  };
  function render() { window.P1Enquiries.render(); }
  function updateSelectedDateSummary() {
    const from = $("dateFrom").value;
    const to = $("dateTo").value;
    const summary = $("selectedDateSummary");
    const format = value => {
      if (!value) return "";
      const [year, month, day] = value.split("-");
      return new Date(Number(year), Number(month) - 1, Number(day)).toLocaleDateString("en-IN", { day: "2-digit", month: "short", year: "numeric" });
    };
    if (from && to) summary.textContent = from === to ? `Selected date: ${format(from)}` : `Selected dates: ${format(from)} – ${format(to)}`;
    else if (from) summary.textContent = `From ${format(from)} onwards`;
    else if (to) summary.textContent = `Up to ${format(to)}`;
    else summary.textContent = "Showing all dates";
  }
  ["searchInput","sourceFilter","urgencyFilter","statusFilter","dateFrom","dateTo"].forEach(id => $(id).addEventListener(id==="searchInput"?"input":"change", () => {
    if (id === "dateFrom" || id === "dateTo") updateSelectedDateSummary();
    render();
  }));
  const filterToggle = $("filterToggle"), filterPanel = $("filterPanel"), filterBadge = $("filterBadge");
  const filterIds = ["sourceFilter","urgencyFilter","statusFilter","dateFrom","dateTo"];
  function updateFilterBadge() {
    const active = filterIds.filter(id => $(id).value).length;
    filterBadge.textContent = active; filterBadge.hidden = !active;
    filterToggle.classList.toggle("has-filters", active > 0);
    $("clearAllFilters").hidden = !(active > 0 || $("searchInput").value.trim());
  }
  filterToggle.addEventListener("click", () => {
    const open = filterPanel.hidden;
    filterPanel.hidden = !open;
    filterToggle.setAttribute("aria-expanded", String(open));
    filterToggle.classList.toggle("open", open);
  });
  filterIds.forEach(id => $(id).addEventListener("change", updateFilterBadge));
  $("searchInput").addEventListener("input", updateFilterBadge);
  function clearAllFilters() {
    $("searchInput").value = "";
    filterIds.forEach(id => { $(id).value = ""; });
    updateFilterBadge(); updateSelectedDateSummary(); render();
  }
  $("clearFilters").addEventListener("click", clearAllFilters);
  $("clearAllFilters").addEventListener("click", clearAllFilters);
  $("refreshQueue").addEventListener("click", async () => {
    try { await window.P1Enquiries.refresh(); render(); window.P1Toast.show("Enquiry queue refreshed.","success"); }
    catch(error) { window.P1Toast.show(`Queue refresh failed: ${error.message}`,"error"); }
  });
  $("refreshAll")?.addEventListener("click", async () => {
    try {
      await window.P1API.health();
      await window.P1Enquiries.refresh(); render(); window.P1Toast.show("Dashboard refreshed.","success");
    } catch(error) { window.P1Toast.show(`Could not refresh from API: ${error.message}`,"error"); }
  });
  $("exportCsv").addEventListener("click", () => {
    const rows=window.P1Enquiries.getFiltered();
    const headers=["enquiry_id","patient_name","patient_country","source","condition","urgency","status","received_at"];
    const csv=[headers.join(","),...rows.map(r=>headers.map(k=>`"${String(r[k]??"").replace(/"/g,'""')}"`).join(","))].join("\r\n");
    const blob=new Blob([csv],{type:"text/csv;charset=utf-8;"}), url=URL.createObjectURL(blob), a=document.createElement("a");
    a.href=url;a.download="p1-enquiries.csv";a.click();URL.revokeObjectURL(url);
    window.P1Toast.show("CSV exported from the currently visible filtered queue.","success");
  });
  $("enquiryTableBody").addEventListener("click",event => {
    const link=event.target.closest("[data-crm]");
    if(link){event.preventDefault();window.P1Toast.show("CRM is not connected.","error");}
  });
  $("currentDate").textContent=new Date().toLocaleDateString("en-IN",{weekday:"short",day:"2-digit",month:"short",year:"numeric"});
  $("connectionText").textContent="Connecting to backend…";
  window.P1API.health()
    .then(()=>{ $("connectionText").textContent="Backend connected"; window.P1Toast.show("Backend health check passed.","success"); })
    .catch(err=>{ $("connectionText").textContent="Backend unavailable"; window.P1Toast.show(`Backend is unavailable: ${err.message}`,"error"); });
  render();
  window.P1Enquiries.refresh().then(render).catch(err=>window.P1Toast.show(`Initial queue load failed: ${err.message}`,"error"));
  setInterval(()=>window.P1Enquiries.refresh().then(render).catch(()=>{}),10000);
})();

/* ===== NAVIGATION ===== */
(function () {
  const links = Array.from(document.querySelectorAll('.nav-link[data-page]'));
  const pages = Array.from(document.querySelectorAll('.dashboard-page'));
  function showPage(id) {
    pages.forEach(page => page.classList.toggle('active', page.id === id));
    links.forEach(link => link.classList.toggle('active', link.dataset.page === id));
    const active = links.find(link => link.dataset.page === id);
    const crumb = document.querySelector('.breadcrumb strong');
    if (crumb && active) crumb.textContent = active.textContent.trim().replace(/\\s+\\d+$/, '');
    if (id) history.replaceState(null, '', '#' + id);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }
  links.forEach(link => link.addEventListener('click', event => {
    event.preventDefault();
    showPage(link.dataset.page);
  }));
  window.P1Nav = { showPage };
  const initial = location.hash.replace('#', '');
  showPage(pages.some(page => page.id === initial) ? initial : 'page-operations');
})();

/* ===== REPLY BOXES ===== */
/* Frontend-only AI reply display. Backend teammate can call window.setChannelAIReply(channel, text, status). */
window.setChannelAIReply = function (channel, text, statusText) {
  const ids = {
    email: "emailReplyBox",
    salesiq: "salesiqReplyBox",
    whatsapp: "whatsappReplyBox"
  };
  const box = document.getElementById(ids[String(channel).toLowerCase()]);
  if (!box) return;
  const textarea = box.querySelector(".ai-reply-text");
  const status = box.querySelector(".reply-status");
  if (textarea) textarea.value = text || "";
  if (status) status.textContent = statusText || "AI reply received";
};

