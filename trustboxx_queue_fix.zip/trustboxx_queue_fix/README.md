# No Overnight Enquiry Wait — Light UI

## Pages
- Enquiry operations
- Enquiry queue
- AI chatbot: submits each visitor message to the backend and waits for a reply
- Email simulation: submits an email enquiry and shows the backend response

## Run
Open this folder in VS Code. Start the backend, then run a static server from this folder:

```powershell
python -m http.server 5500 --bind 127.0.0.1
```

Open http://127.0.0.1:5500/

## Backend configuration
The frontend uses the existing `window.ENV` configuration block at the top of `js/app.js`. Change `API_BASE_URL` there to the backend host reachable from the browser. The provided `.env` file documents the same value, but plain HTML/JavaScript does not automatically load `.env`; keep the values in sync manually unless you add a build tool.

Current URL: `http://192.168.1.104:8000`

Existing endpoints used:
- `POST /api/enquiry`
- `GET /api/enquiry/{enquiry_id}`
- `GET /api/enquiry/{enquiry_id}/messages`
- `GET /api/enquiries`
- `GET /api/health`
- `GET /api/digest/preview`
- `POST /api/digest/send`

The chatbot and email simulation submit through `POST /api/enquiry`, then check the enquiry and its messages for a response. The backend must enable CORS for the frontend origin.

## AI reply compatibility
The frontend looks for common response fields such as `ai_reply`, `reply`, `response`, `answer`, `assistant_response`, `generated_reply`, `content`, and nested `messages` / `data` objects. If your backend uses a different response schema, update `extractReply()` in `js/app.js` to match it. It does not generate a fake AI response.


## UI update
The dashboard now uses a consistent light white-and-blue theme with a compact horizontal navigation bar across the operations, queue, AI chatbot, and email simulation pages. Existing API configuration and JavaScript behavior are retained.


The Workspace/current-page breadcrumb row has been removed from all pages; top-right refresh and profile controls remain visible.

## AI reply flow (chatbot + email)
`POST /api/enquiry` only returns an acknowledgement. The frontend then polls `GET /api/enquiry/{enquiry_id}/messages` every 2 seconds (up to ~90 s) and shows the newest assistant message. It also checks `GET /api/enquiry/{enquiry_id}` and stops early if the status is `held_for_human`, `failed` or `error`. If your messages schema differs, adjust `TEXT_KEYS`, `SENDER_KEYS` and `pickAiReply()` in `js/app.js`.

## Digest preview page
The operations page has the **Preview digest** button. It opens the separate **Digest preview** page (next to Email simulation), which calls `GET /api/digest/preview` and shows the leads in a table grouped by Urgent / Standard / Info only. Rows are read from the backend's `html_body`; if that is missing the table is built from the queue records. **Send digest now** stays on the operations page.
